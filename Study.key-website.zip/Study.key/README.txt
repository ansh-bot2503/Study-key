STUDY.KEY WEBSITE — QUICK START

Files:
- index.html: the complete responsive website
- samples/science-sample.pdf: placeholder sample PDF (replace it with your own original PDF)
- README.txt: these instructions

EDIT BEFORE PUBLISHING:
1. Open index.html in a text editor.
2. Find CONTACT_EMAIL near the bottom.
3. Ask your parent/guardian to replace YOUR_PARENT_OR_GUARDIAN_EMAIL@example.com with an email address they supervise.
4. Replace the sample PDF in the samples folder with your own original study notes. Keep the same filename, or update the link in index.html.
5. Update the placeholder cards and prices to match the notes you have actually created.

IMPORTANT:
- This is a static website. It does not store uploaded PDFs or process payments.
- Do not add a payment gateway or collect payment details yourself. Because you are 14, a parent/guardian should supervise any paid orders, communication and payments.
- Publish only notes you wrote yourself. Do not copy and sell copyrighted textbook PDFs or publisher materials.
- Never publish your home address, phone number, school details, passwords, bank details or OTPs.
- The request form opens the visitor's email app; it does not save submissions to a database.
- For public hosting, ask a parent/guardian to help upload the folder to a static website host. Keep the samples folder alongside index.html.
